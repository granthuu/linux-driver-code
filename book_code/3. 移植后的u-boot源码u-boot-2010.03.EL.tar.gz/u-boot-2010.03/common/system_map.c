/*
 * The builtin symbol table for use with kallsyms
 *
 * Copyright (c) 2008-2009 Analog Devices Inc.
 * Licensed under the GPL-2 or later.
 */

const char const system_map[] = SYSTEM_MAP;
